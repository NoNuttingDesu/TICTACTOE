import java.util.Scanner;

public class timer {
    static Scanner input = new Scanner(System.in);
    public static void main(String[] args) throws InterruptedException{
        int min, sec;

        System.out.println("Welcome to a basic timer by Collin Le!");

        System.out.println("Enter Minute(s)");
        min = input.nextInt();
        System.out.println("Enter second(s)");
        sec = input.nextInt();

        int totalTimeInSeconds = min * 60 + sec;

        while(totalTimeInSeconds > 0){
            min = totalTimeInSeconds / 60;
            sec = totalTimeInSeconds % 60;

            System.out.printf("Timer: %02d: %02d\n", min, sec);

            Thread.sleep(1000);

            totalTimeInSeconds--;
        }

        System.out.println("Time's up!");
    }
}
