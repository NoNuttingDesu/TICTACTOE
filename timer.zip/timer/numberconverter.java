import java.util.*;

public class numberconverter {
    static Scanner input = new Scanner(System.in);
    public static void main(String[] args) {
        int num;

        System.out.println("Welcome to number to text converter!\nBegin by entering a number: ");
        num = input.nextInt();

        String result = convertNumberToText(num);
        System.out.println(result);

    }

    public static String convertNumberToText(int num){
        if (num == 0) return "zero";

        StringBuilder numToText = new StringBuilder();

        int thousands = num / 1000;
        num = num % 1000;

        int hundreds = num / 100;
        num = num % 100;

        int tens = num / 10;
        int ones = num % 10;

        if(thousands > 0){
            numToText.append(getOnes(thousands)).append( "-thousand ");
        }
        if(hundreds > 0){
            numToText.append(getOnes(hundreds)).append("-hundred ");
        }
        if(tens > 1){
            numToText.append(getTens(tens)).append(" ");
            if(ones > 0){
                numToText.append(getOnes(ones));
            }
        }

        else if(tens == 1){
            numToText.append(getTeens(ones));
        }
        else if(ones > 0){
            numToText.append(getOnes(ones));
        }

        return numToText.toString().trim();
    }

    public static String getOnes(int index){
        switch(index){
            case 1: return "one";
            case 2: return "two";
            case 3: return "three";
            case 4: return "four";
            case 5: return "five";
            case 6: return "six";
            case 7: return "seven";
            case 8: return "eight";
            case 9: return "nine";
            default: return "";
        }
    }

    public static String getTens(int index){
        switch(index){
            case 2: return "twenty";
            case 3: return "thirty";
            case 4: return "fourty";
            case 5: return "fifty";
            case 6: return "sixty";
            case 7: return "seventy";
            case 8: return "eighty";
            case 9: return "ninety";
            default: return "";
        }
    }

    public static String getTeens(int index){
        switch(index){
            case 0: return "ten";
            case 1: return "eleven";
            case 2: return "twelve";
            case 3: return "thirteen";
            case 4: return "fourteen";
            case 5: return "fifteen";
            case 6: return "sixteen";
            case 7: return "seventeen";
            case 8: return "eightteen";
            case 9: return "nineteen";
            default: return "";
        }
    }
}
