import javax.swing.Timer;
import javax.swing.*;
import java.awt.*;

public class timerapp {
    public static void main(String[] args) {
        
    JFrame window = new JFrame("Hentai Timer");
    JLabel displayTimer = new JLabel("00:00", SwingConstants.CENTER);
    displayTimer.setFont(new Font("Serif", Font.PLAIN, 40));
    displayTimer.setHorizontalAlignment(SwingConstants.CENTER);

    JButton start = new JButton("START");
    JButton reset = new JButton("RESET");
    JButton pause = new JButton("PAUSE");
    JButton increaseMin = new JButton("+");
    JButton increaseSec = new JButton("+");
    JButton decreaseMin = new JButton("-");
    JButton decreaseSec = new JButton("-");

    
    //VALUES
    int[] minutes = {0};
    int[] seconds = {0};


    window.setLayout(new BorderLayout());

    JPanel timePanel = new JPanel();
    timePanel.setLayout(new GridBagLayout());
    GridBagConstraints gbc = new GridBagConstraints();
    timePanel.setPreferredSize(new Dimension(200, 150));
    
    //JLabel minLabel = new JLabel("");
    JLabel minValue = new JLabel(String.valueOf(minutes[0]));
    minValue.setHorizontalAlignment(SwingConstants.CENTER);
    //JLabel secLabel = new JLabel("");
    JLabel secValue = new JLabel(String.valueOf(minutes[0]));
    secValue.setHorizontalAlignment(SwingConstants.CENTER);

    gbc.gridx = 0; gbc.gridy = 0;
    timePanel.add(increaseMin, gbc);
    gbc.gridx = 1;
    timePanel.add(increaseSec, gbc);

    gbc.gridx = 0; gbc.gridy = 1;
    //timePanel.add(minLabel, gbc);
    gbc.gridx = 1;
    //timePanel.add(minValue, gbc);
    gbc.gridx = 2;
    //timePanel.add(secLabel, gbc);
    gbc.gridx = 3;
    //timePanel.add(secValue, gbc);

    gbc.gridx = 0; gbc.gridy = 2;
    timePanel.add(decreaseMin, gbc);
    gbc.gridx = 1;
    timePanel.add(decreaseSec, gbc);

    //START, RESET, PAUSE Button Layouts
    JPanel buttonPanel = new JPanel();
    buttonPanel.setLayout(new FlowLayout());
    buttonPanel.add(start);
    buttonPanel.add(reset);
    buttonPanel.add(pause);

    //Window
    window.add(displayTimer, BorderLayout.CENTER);
    window.add(timePanel,BorderLayout.NORTH);
    window.add(buttonPanel, BorderLayout.SOUTH);


    Timer timer = new Timer(1000, e -> {
        if(seconds[0] == 0 && minutes[0] == 0){
            ((Timer) e.getSource()).stop();
        } else if(seconds[0] > 0){
            seconds[0]--;
        } else if(minutes[0] > 0){
            minutes[0]--;
            seconds[0] = 59;
        }
        
        displayTimer.setText(String.format("%02d:%02d", minutes[0], seconds[0]));
    });

    start.addActionListener(e -> {
        timer.start();
    });

    pause.addActionListener(e -> {
        timer.stop();
    });
    
    reset.addActionListener(e ->{
        timer.stop();
        minutes[0] = 0;
        seconds[0] = 0;
        displayTimer.setText("00:00");
    });

    increaseMin.addActionListener(e -> {
        minutes[0]++;
        minValue.setText(String.valueOf(minutes[0]));
        displayTimer.setText(String.format("%02d:%02d", minutes[0], seconds[0]));
    });

    increaseSec.addActionListener(e -> {
        if(seconds[0] == 59){
            seconds[0] = 0;
            minutes[0]++;
            minValue.setText(String.valueOf(minutes[0]));
        } else{
            seconds[0]++;
        }
        secValue.setText(String.valueOf(seconds[0]));
        displayTimer.setText(String.format("%02d:%02d", minutes[0], seconds[0]));
    });

    decreaseMin.addActionListener(e -> {
        if(minutes[0] > 0){
            minutes[0]--;
            minValue.setText(String.valueOf(minutes[0]));
            displayTimer.setText(String.format("%02d:%02d", minutes[0], seconds[0]));
        }
    });

    decreaseSec.addActionListener(e -> {
        if(seconds[0] > 0){
            seconds[0]--;
        } else if(minutes[0] > 0){
            minutes[0]--;
            seconds[0] = 59;
        }
        secValue.setText(String.valueOf(seconds[0]));
        displayTimer.setText(String.format("%02d:%02d", minutes[0], seconds[0]));
    });


    window.setSize(400, 250);
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    window.setResizable(false);
    window.setVisible(true);
    }
}
